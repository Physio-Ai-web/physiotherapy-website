import React from 'react';
export default function Conditions() { return <div>Conditions Information</div>; }