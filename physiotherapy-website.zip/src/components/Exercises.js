import React from 'react';
export default function Exercises() { return <div>Exercise Library</div>; }