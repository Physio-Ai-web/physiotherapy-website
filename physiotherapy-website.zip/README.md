# Physiotherapy AI Website
This is a simple AI-powered physiotherapy website.